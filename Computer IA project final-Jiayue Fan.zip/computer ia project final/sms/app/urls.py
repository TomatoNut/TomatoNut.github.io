from django.urls import path
# from .views import homePageView
from .views import HomePageView, LoginView, RegisterView, GetProductsView, ProductDetailView, ProductUpdateView, \
    ProductDeleteView, CheckoutView
from .views import ProductView

urlpatterns = [
    # path('', homePageView, name='home'),
    path('', HomePageView.as_view(), name='home'),
    path('product/', ProductView.as_view(), name='product'),
    path('checkout/', CheckoutView.as_view(), name='checkout'),
    path('product/list/', GetProductsView.as_view(), name='productList'),
    path('product/update/', ProductUpdateView.as_view(), name='productUpdate'),
    path('product/delete/', ProductDeleteView.as_view(), name='productDelete'),
    path('login/', LoginView.as_view(), name='login'),
    path('register/', RegisterView.as_view(), name='register'),
    path('product/detail/', ProductDetailView.as_view(), name='productDetail'),

]
