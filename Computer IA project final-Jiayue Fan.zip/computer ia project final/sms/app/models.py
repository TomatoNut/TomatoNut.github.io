from django.db import models
#creating fields to the models, linking to the correspondent database
#each field in model= a coulumn in database

#storing login information
class User(models.Model):
    id = models.AutoField(primary_key=True) #define id modal field to be the primary key
    username = models.CharField(max_length=300)
    password = models.CharField(max_length=300)
    phone = models.CharField(max_length=300)
    name = models.CharField(max_length=300)

#str method: default Python method to return a string that can 
# be understood by human to represents the object(object name) = often used for admin
    def __str__(self):
        return f'{self.name}'
    ##return self. name


#sotirng product information
class Product(models.Model):
    id = models.AutoField(primary_key=True)
    image = models.CharField(max_length=1000, null=True, default=None)
    name = models.CharField(max_length=100)
    category = models.IntegerField(default=1)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    number = models.IntegerField(default=0)

    def __str__(self):
        return f'{self.name}'
        ##rerturn self. name

#create data migration to synchronize models to database