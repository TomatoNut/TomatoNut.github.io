import json
import time
from datetime import datetime

import jwt
from django.db.models import F
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.views import View
from django.views.generic import TemplateView, CreateView

from config import settings
from .models import Product, User


# 登录验证装饰器
def authenticate(viewfunc):
    def wrapper(request):
        # 认证越早越好
        jwtheader = request.META.get("token")
        # print(request.META.keys())
        # print(request.META["HTTP_COOKIE"].get(settings.AUTH_HEADER,""))
        # print(request.META["HTTP_COOKIE"])
        print("-   ------------")
        if not jwtheader:
            return HttpResponse(status=401)
        print(jwtheader)
        # 解码
        try:
            payload = jwt.decode(jwtheader, settings.SECRET_KEY, algorithms=["HS256"])
            # payload = "aa"
            print(payload)
        except Exception as e:  # 解码有任何异常，都不能通过认证
            print(e)
            return HttpResponse(status=401)

        # 是否过期ToDO
        print("- " * 30)
        try:
            user_id = payload.get("user_id", 0)
            if user_id == 0:
                return HttpResponse(status=401)
            user = User.objects.get(id=user_id)
            request.user = user
        except Exception as e:
            print(e)
            return HttpResponse(status=401)
        response = viewfunc(request)
        return response

    return wrapper


# 对id签名
def gen_token(user_id):
    # 时间戳用来判断是否过期，以便重发token或重新登录
    return jwt.encode({
        "user_id": user_id,
        "exp": int(datetime.now().timestamp()) + settings.AUTH_EXPIRE  # 取整
    }, settings.SECRET_KEY, algorithm="HS256")


# Create your views here.
# def homePageView(request):
#    return HttpResponse('Hello, World now!')

class HomePageView(
    TemplateView):  # define a class-based view called HomePageView which inherits from the parent class TemplateView
    template_name = 'home.html'


class CheckoutView(View):

    def get(self, request):
        return render(request, 'checkout.html')

    def post(self, request):
        # 验证用户名和密码
        v_list = json.loads(request.POST.get('v_list'))
        for i in v_list:
            Product.objects.filter(id=i["id"]).update(number=F("number") - int(i["num"]))

        # 失败返回错误信息和400，所有其他错误一律用户名密码错误
        return JsonResponse({"msg": "ok", "code": 200})


class ProductView(View):

    def get(self, request):
        return render(request, 'product.html')

    def post(self, request):
        name = request.POST.get('name')
        price = request.POST.get('price')
        category = request.POST.get('category')
        number = request.POST.get('number')
        image = request.FILES.get("image")
        file_path = f"/static/images/{int(time.time())}" + image.name
        with open('.' + file_path, 'wb') as f:
            f.write(image.read())
        product = Product.objects.create(name=name, price=price, category=category, number=number, image=file_path)

        # 失败返回错误信息和400，所有其他错误一律用户名密码错误
        return JsonResponse({"msg": "ok", "code": 200})


class ProductUpdateView(View):

    def post(self, request):
        name = request.POST.get('name')
        price = request.POST.get('price')
        id = request.POST.get('id')
        category = request.POST.get('category')
        number = request.POST.get('number')
        image = request.FILES.get("image")
        if image not in (None, "null", "undefined", "", " "):
            file_path = f"/static/images/{int(time.time())}" + image.name
            with open('.' + file_path, 'wb') as f:
                f.write(image.read())
        else:
            file_path = request.POST.get("image1")
        product = Product.objects.filter(id=id).update(name=name, price=price, category=category, number=number,
                                                       image=file_path)

        # 失败返回错误信息和400，所有其他错误一律用户名密码错误
        return JsonResponse({"msg": "ok", "code": 200})


class ProductDeleteView(View):

    def post(self, request):
        ids_list = request.POST.get('ids_list')

        Product.objects.filter(id__in=ids_list).delete()
        # 失败返回错误信息和400，所有其他错误一律用户名密码错误
        return JsonResponse({"msg": "ok", "code": 200})


class LoginView(View):
    def get(self, request):
        return render(request, 'login.html')

    def post(self, request):
        # 验证用户名和密码
        username = request.POST.get('username')
        password = request.POST.get('password')
        try:
            user = User.objects.get(username=username, password=password)

            # only one

            # 验证成功
            token = gen_token(user.id)

            res = JsonResponse({
                "code": 200, "data": {
                    "name": user.name,
                    "token": token},
                "msg": "ok"
            })  # 返回200
            res.set_cookie("token", token)
            return res

        except Exception as e:

            # 失败返回错误信息和400，所有其他错误一律用户名密码错误
            return JsonResponse({"msg": "Incorrect username or password", "code": 400})


class GetProductsView(View):

    def get(self, request):
        type = request.GET.get('type', None)
        order_type = request.GET.get('order_type')
        if type:
            product_list = Product.objects.filter(category=type)
        else:
            product_list = Product.objects.filter(number__gt=0)
        if order_type in (1, "1"):
            product_list = product_list.order_by("-id")
        else:
            product_list = product_list.order_by("-number")
        return JsonResponse({"msg": "OK", "code": 200, "data": [
            {"id": product.id, "name": product.name, "image": product.image, "category": product.category,
             "price": product.price, "number": product.number} for product in product_list]})


class RegisterView(View):

    def post(self, request):
        # 验证用户名和密码
        username = request.POST.get('username')
        password = request.POST.get('password')
        name = request.POST.get('name')
        phone = request.POST.get('name')
        try:
            user = User.objects.get(username=username)
            return JsonResponse({"msg": "The account already exists in the system", "code": 400})
        except User.DoesNotExist:

            user = User.objects.create(username=username, password=password, name=name, phone=phone)
            return JsonResponse({"msg": "ok", "code": 200})


class ProductDetailView(View):

    def get(self, request):
        # 验证用户名和密码
        id = request.GET.get("id")
        try:
            product = Product.objects.get(id=id)
            return JsonResponse({"msg": "OK", "code": 200, "data":
                {"id": product.id, "name": product.name, "image": product.image, "category": product.category,
                 "price": product.price, "number": product.number}})
        except Exception as e:
            return JsonResponse({"msg": "The product doesn't exist", "code": 400})
